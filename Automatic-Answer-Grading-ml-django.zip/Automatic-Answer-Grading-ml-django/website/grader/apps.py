from django.apps import AppConfig


class GraderConfig(AppConfig):
    name = 'grader'
